package com.metrolist.desktop.utils

import com.metrolist.desktop.crash.DesktopCrashRecovery
import java.lang.management.ManagementFactory

internal fun desktopRestartCommand(): List<String> {
    val info = ProcessHandle.current().info()
    val classPath = System.getProperty("java.class.path", "")
    val mainCommand = System.getProperty("sun.java.command", "")
    return desktopRestartCommand(
        appImage = System.getenv("APPIMAGE"),
        jpackagePath = System.getProperty("jpackage.app-path"),
        command = info.command().orElse(null),
        processArguments = info.arguments().orElse(null)?.toList(),
        jvmArguments = ManagementFactory.getRuntimeMXBean().inputArguments,
        classPath = classPath,
        mainClass =
            if (classPath.endsWith(".jar") && (mainCommand == classPath || mainCommand.startsWith("$classPath "))) {
                classPath
            } else {
                mainCommand.substringBefore(' ')
            },
    )
}

internal fun desktopRestartCommand(
    appImage: String?,
    command: String?,
    processArguments: List<String>?,
    jvmArguments: List<String>,
    classPath: String,
    mainClass: String,
    jpackagePath: String? = null,
    osName: String = System.getProperty("os.name"),
): List<String> {
    val launcher = appImage?.takeIf(String::isNotBlank) ?: jpackagePath?.takeIf(String::isNotBlank)
    val executable = requireNotNull(launcher ?: command) { "Current application command is unavailable" }
    val java = command?.substringAfterLast('/')?.substringAfterLast('\\')?.lowercase() in setOf("java", "java.exe", "javaw.exe")
    val arguments = processArguments.orEmpty()
    val launchArguments =
        if (launcher != null || !java) {
            if (java || command == null) emptyList() else arguments
        } else if (arguments.contains(mainClass) || arguments.indexOf("-jar").let { it >= 0 && it + 1 < arguments.size }) {
            arguments
        } else {
            require(classPath.isNotBlank() && mainClass.isNotBlank()) { "Cannot determine desktop restart command" }
            jvmArguments + if (mainClass.endsWith(".jar")) listOf("-jar", mainClass) else listOf("-cp", classPath, mainClass)
        }
    val recoveryIndex = launchArguments.indexOf(DesktopCrashRecovery.ARGUMENT)
    val restartArguments =
        if (recoveryIndex < 0) launchArguments else launchArguments.take(recoveryIndex) + launchArguments.drop(recoveryIndex + 2)
    val appCommand = listOf(executable) + restartArguments
    return if (osName.startsWith("Mac", ignoreCase = true)) {
        macOSAppRelaunchCommand(appCommand)
    } else {
        appCommand
    }
}

internal fun macOSAppRelaunchCommand(appCommand: List<String>): List<String> {
    val executable = appCommand.firstOrNull() ?: return appCommand
    val contentsPath = "/Contents/MacOS/"
    val contentsIndex = executable.indexOf(contentsPath)
    val appBundle =
        executable
            .takeIf { contentsIndex > 0 }
            ?.substring(0, contentsIndex)
            ?.takeIf { it.endsWith(".app") }
            ?: return appCommand
    return listOf("/usr/bin/open", "-n", "-a", appBundle, "--args") + appCommand.drop(1)
}

// Java passes an argument that is already wrapped in quotes through unchanged, and cmd /c strips only that
// outer pair, so every app argument keeps its own quotes, including paths with spaces.
internal fun windowsDelayedRestartCommand(appCommand: List<String>): List<String> =
    listOf("cmd", "/c", "\"ping -n 2 127.0.0.1 >nul & start \"\" ${appCommand.joinToString(" ") { "\"$it\"" }}\"")

internal fun ProcessBuilder.prepareDesktopRelaunch(): ProcessBuilder =
    apply {
        environment().remove("_JPACKAGE_LAUNCHER")
        if (System.getProperty("os.name").startsWith("Mac", ignoreCase = true)) {
            val command = command()
            val launcherIndex = command.indexOf("/usr/bin/open")
            val argsIndex = command.indexOf("--args")
            if (launcherIndex >= 0 && argsIndex > launcherIndex) {
                val environmentOptions = environment().toSortedMap().flatMap { (name, value) -> listOf("--env", "$name=$value") }
                command(command.take(argsIndex) + environmentOptions + command.drop(argsIndex))
            }
        }
    }
